import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-importFile',
  templateUrl: './importFile.component.html',
  styleUrls: ['./importFile.component.scss']
})
export class ImportFileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
