import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editFile',
  templateUrl: './editFile.component.html',
  styleUrls: ['./editFile.component.scss']
})
export class EditFileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
