import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { AppRoutes } from './app.routes';
import { AppMenuComponent, AppSubMenuComponent } from './app.menu.component';
import { AppTopBarComponent } from './app.topbar.component';
import { AppFooterComponent } from './app.footer.component';
import { DashboardComponent } from './pages/dashboard.component';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { ButtonModule } from 'primeng/button';
import { ExcelImportComponent } from './excelImport/excelImport.component';
import { ExcelEditComponent } from './excelEdit/excelEdit.component';
import { CombinedMasterDTRReportComponent } from './combinedMasterDTRReport/combinedMasterDTRReport.component';
import { TargetReportComponent } from './targetReport/targetReport.component';
import { DormantReportComponent } from './dormantReport/dormantReport.component';
import { DtrFlashCodesComponent } from './dtrFlashCodes/dtrFlashCodes.component';

import { FileUploadModule } from 'primeng/fileupload';
import {InputTextModule} from 'primeng/inputtext';
import {CheckboxModule} from 'primeng/checkbox';
import {RadioButtonModule} from 'primeng/radiobutton';
import {DropdownModule} from 'primeng/dropdown';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {TabViewModule} from 'primeng/tabview';

import { HttpClientModule } from '@angular/common/http';

import {FormsModule} from '@angular/forms';

@NgModule({
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        AppRoutes,
        ScrollPanelModule,
        ButtonModule,
        FileUploadModule,
        HttpClientModule,
        FormsModule,
        InputTextModule,
        CheckboxModule,
        RadioButtonModule,
        DropdownModule,
        InputTextareaModule,
        TabViewModule
    ],
    declarations: [
        AppComponent,
        AppMenuComponent,
        AppSubMenuComponent,
        AppTopBarComponent,
        AppFooterComponent,
        DashboardComponent,
        ExcelImportComponent,
        ExcelEditComponent,
        CombinedMasterDTRReportComponent,
        TargetReportComponent,
        DormantReportComponent,
        DtrFlashCodesComponent
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }
