import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dormantReport',
  templateUrl: './dormantReport.component.html',
  styleUrls: ['./dormantReport.component.scss']
})
export class DormantReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
