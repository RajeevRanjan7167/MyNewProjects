/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { CombinedMasterDTRReportComponent } from './combinedMasterDTRReport.component';

describe('CombinedMasterDTRReportComponent', () => {
  let component: CombinedMasterDTRReportComponent;
  let fixture: ComponentFixture<CombinedMasterDTRReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CombinedMasterDTRReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CombinedMasterDTRReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
