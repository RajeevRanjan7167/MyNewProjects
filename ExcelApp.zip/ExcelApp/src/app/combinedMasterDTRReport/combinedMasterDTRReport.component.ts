import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-combinedMasterDTRReport',
  templateUrl: './combinedMasterDTRReport.component.html',
  styleUrls: ['./combinedMasterDTRReport.component.scss']
})
export class CombinedMasterDTRReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
