import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-excelEdit',
  templateUrl: './excelEdit.component.html',
  styleUrls: ['./excelEdit.component.scss']
})
export class ExcelEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
