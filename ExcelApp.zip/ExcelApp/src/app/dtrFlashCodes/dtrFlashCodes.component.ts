import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dtrFlashCodes',
  templateUrl: './dtrFlashCodes.component.html',
  styleUrls: ['./dtrFlashCodes.component.scss']
})
export class DtrFlashCodesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
