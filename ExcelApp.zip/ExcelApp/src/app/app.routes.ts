import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { DashboardComponent } from './pages/dashboard.component';
import { ExcelImportComponent } from './excelImport/excelImport.component';
import { ExcelEditComponent } from './excelEdit/excelEdit.component';
import { CombinedMasterDTRReportComponent } from './combinedMasterDTRReport/combinedMasterDTRReport.component';
import { TargetReportComponent } from './targetReport/targetReport.component';
import { DormantReportComponent } from './dormantReport/dormantReport.component';
import { DtrFlashCodesComponent } from './dtrFlashCodes/dtrFlashCodes.component';

export const routes: Routes = [
    { path: '', component: DashboardComponent },
    { path: 'import', component: ExcelImportComponent },
    { path: 'edit', component: ExcelEditComponent },
    { path: 'combinedReport', component: CombinedMasterDTRReportComponent },
    { path: 'targetReport', component: TargetReportComponent },
    { path: 'dormantReport', component: DormantReportComponent },
    { path: 'dtrFlashCodes', component: DtrFlashCodesComponent }
];

export const AppRoutes: ModuleWithProviders = RouterModule.forRoot(routes);
