import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-excelImport',
  templateUrl: './excelImport.component.html',
  styleUrls: ['./excelImport.component.scss']
})
export class ExcelImportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
