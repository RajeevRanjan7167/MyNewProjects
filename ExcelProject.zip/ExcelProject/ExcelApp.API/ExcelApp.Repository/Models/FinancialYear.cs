﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ExcelApp.Repository.Models
{
    public partial class FinancialYear
    {
        public int FinancialYearId { get; set; }
        public string FinancialYearName { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
