﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ExcelApp.Repository.Models
{
    public partial class Agging
    {
        public int AggingId { get; set; }
        public int AggingDays { get; set; }
        public bool? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
