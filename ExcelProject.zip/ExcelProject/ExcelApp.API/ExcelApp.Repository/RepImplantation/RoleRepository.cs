﻿using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepInterfaces;

namespace ExcelApp.Repository.RepImplantation
{
    public class RoleRepository : BaseRepository<Role, ExcelAppContext>, IRoleRepository
    {
        private readonly ExcelAppContext _context;

        public RoleRepository(ExcelAppContext context) : base(context)
        {
            this._context = context;
        }
    }
}