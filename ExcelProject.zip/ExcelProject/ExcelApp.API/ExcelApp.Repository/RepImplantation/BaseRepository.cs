﻿using ExcelApp.Repository.RepInterfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ExcelApp.Repository.RepImplantation
{
    public abstract class BaseRepository<TEntity, TConText> : IBaseRepository<TEntity>
        where TEntity : class
        where TConText : DbContext
    {
        private readonly TConText _context;
        private bool _saveChanges = true;

        public BaseRepository(TConText context)
        {
            this._context = context;
        }

        public async virtual Task<TEntity> Create(TEntity entity)
        {
            _context.Set<TEntity>().Add(entity);
            if (_saveChanges)
                await _context.SaveChangesAsync().ConfigureAwait(false);

            return entity;
        }

        public async virtual Task<TEntity> Delete(object id)
        {
            var entity = await Get(id).ConfigureAwait(false);
            if (entity == null)
                return entity;

            _context.Remove(entity);
            if (_saveChanges)
                await _context.SaveChangesAsync().ConfigureAwait(false);

            return entity;
        }

        public async virtual Task<List<TEntity>> GetAll()
        {
            return await _context.Set<TEntity>().ToListAsync().ConfigureAwait(false);
        }

        public async virtual Task<TEntity> Get(object id)
        {
            return await _context.Set<TEntity>().FindAsync(id).ConfigureAwait(false);
        }

        public async Task SaveChangesAsync()
        {
            if (_saveChanges)
                await _context.SaveChangesAsync().ConfigureAwait(false);
        }

        public async Task<TEntity> Update(TEntity entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            if (_saveChanges)
                await _context.SaveChangesAsync().ConfigureAwait(false);

            return entity;
        }       

        public virtual IBaseRepository<TEntity> WithoutSave()
        {
            _saveChanges = false;
            return this;
        }

        public virtual IBaseRepository<TEntity> WithSave()
        {
            _saveChanges = true;
            return this;
        }
    }
}
