﻿using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepInterfaces;

namespace ExcelApp.Repository.RepImplantation
{
    public class FileUploadRepository : BaseRepository<FileUpload, ExcelAppContext>, IFileUploadRepository
    {
        private readonly ExcelAppContext _context;

        public FileUploadRepository(ExcelAppContext context) : base(context)
        {
            this._context = context;
        }
    }
}
