﻿using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepInterfaces;

namespace ExcelApp.Repository.RepImplantation
{
    public class FinancialYearRepository : BaseRepository<FinancialYear, ExcelAppContext>, IFinancialYearRepository
    {
        private readonly ExcelAppContext _context;

        public FinancialYearRepository(ExcelAppContext context) : base(context)
        {
            this._context = context;
        }
    }
}
