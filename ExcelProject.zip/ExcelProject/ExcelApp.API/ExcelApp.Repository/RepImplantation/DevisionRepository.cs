﻿using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepInterfaces;

namespace ExcelApp.Repository.RepImplantation
{
    public class DevisionRepository : BaseRepository<Devision, ExcelAppContext>, IDevisionRepository
    {
        private readonly ExcelAppContext _context;

        public DevisionRepository(ExcelAppContext context) : base(context)
        {
            this._context = context;
        }
    }
}

