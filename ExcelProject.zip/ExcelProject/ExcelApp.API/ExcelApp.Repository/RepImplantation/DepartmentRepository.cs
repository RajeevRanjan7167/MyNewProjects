﻿using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepInterfaces;

namespace ExcelApp.Repository.RepImplantation
{
    public class DepartmentRepository : BaseRepository<Departmet, ExcelAppContext>, IDepartmentRepository
    {
        private readonly ExcelAppContext _context;

        public DepartmentRepository(ExcelAppContext context) : base(context)
        {
            this._context = context;
        }
    }
}
