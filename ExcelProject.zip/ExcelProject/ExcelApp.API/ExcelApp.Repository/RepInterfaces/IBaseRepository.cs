﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace ExcelApp.Repository.RepInterfaces
{
    public interface IBaseRepository<T> where T : class
    {
        Task<List<T>> GetAll();
        Task<T> Get(object id);
        Task<T> Create(T entity);
        Task<T> Update(T entity);
        Task<T> Delete(object id);
        // int Count(Expression<Func<T, bool>> expression);
        IBaseRepository<T> WithoutSave();
        IBaseRepository<T> WithSave();
        Task SaveChangesAsync();
    }
}
