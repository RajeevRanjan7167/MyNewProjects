﻿using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepImplantation;
using ExcelApp.Repository.RepInterfaces;
using ExcelApp.Service.IServices;
using ExcelApp.Service.Services;
using Microsoft.Extensions.DependencyInjection;

namespace ExcelApp.IOC
{
    public static class IocContainer
    {
        public static void ConfigureIOC(this IServiceCollection services)
        {
            services.AddTransient<IAgingRepository, AgingRepository>();
            services.AddTransient<IAgging, AggingService>();
            services.AddTransient<IDepartmentRepository, DepartmentRepository>();
            services.AddTransient<IDepartmet, DepartmetServices>();
            services.AddTransient<IDevisionRepository, DevisionRepository>();
            services.AddTransient<IDevision, DevisionService>();
            services.AddTransient<IFinancialYearRepository, FinancialYearRepository>();
            services.AddTransient<IFinancialYear, FinancialYearService>();
            services.AddTransient<IRoleRepository, RoleRepository>();
            services.AddTransient<IRoles, RolesService>();

            services.AddTransient<IFileUploadRepository, FileUploadRepository>();
            services.AddTransient<IFileUploadService, FileUploadService>();

            services.AddDbContext<ExcelAppContext>();
        }
    }
}
