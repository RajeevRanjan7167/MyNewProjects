﻿using AutoMapper;
using ExcelApp.Infrastructure;
using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepInterfaces;
using ExcelApp.Service.IServices;

namespace ExcelApp.Service.Services
{
    public class FileUploadService : BaseService<FileUploadDM, IFileUploadRepository, FileUpload>, IFileUploadService
    {
        private readonly IFileUploadRepository _fileUploadRepository;
        private readonly IMapper _mapper;
        private readonly ExcelAppContext _excelAppContext;

        public FileUploadService(IFileUploadRepository fileUploadRepository, IMapper mapper, ExcelAppContext excelAppContext) : base(fileUploadRepository, mapper)
        {
            this._fileUploadRepository = fileUploadRepository;
            this._mapper = mapper;
            this._excelAppContext = excelAppContext;
        }
    }
}

