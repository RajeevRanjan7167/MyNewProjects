﻿using AutoMapper;
using ExcelApp.Infrastructure;
using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepInterfaces;
using ExcelApp.Service.IServices;

namespace ExcelApp.Service.Services
{
    public class DepartmetServices : BaseService<DepartmetDM, IDepartmentRepository, Departmet>, IDepartmet
    {
        private readonly IDepartmentRepository _departmentRepository;
        private readonly IMapper _mapper;
        private readonly ExcelAppContext _excelAppContext;

        public DepartmetServices(IDepartmentRepository departmentRepository, IMapper mapper, ExcelAppContext excelAppContext) : base(departmentRepository, mapper)
        {
            this._departmentRepository = departmentRepository;
            this._mapper = mapper;
            this._excelAppContext = excelAppContext;
        }
    }
}