﻿using AutoMapper;
using ExcelApp.Infrastructure;
using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepInterfaces;
using ExcelApp.Service.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ExcelApp.Service.Services
{
    public class AggingService : BaseService<AggingDM, IAgingRepository, Agging>, IAgging
    {
        private readonly IAgingRepository _agingRepository;
        private readonly IMapper _mapper;
        private readonly ExcelAppContext _excelAppContext;

        public AggingService(IAgingRepository agingRepository, IMapper mapper, ExcelAppContext excelAppContext) : base(agingRepository, mapper)
        {
            this._agingRepository = agingRepository;
            this._mapper = mapper;
            this._excelAppContext = excelAppContext;
        }
    }
}