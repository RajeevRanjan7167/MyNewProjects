﻿using AutoMapper;
using ExcelApp.Infrastructure;
using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepInterfaces;
using ExcelApp.Service.IServices;

namespace ExcelApp.Service.Services
{
    public class RolesService : BaseService<RolesDM, IRoleRepository, Role>, IRoles
    {
        private readonly IRoleRepository _roleRepository;
        private readonly IMapper _mapper;
        private readonly ExcelAppContext _excelAppContext;

        public RolesService(IRoleRepository roleRepository, IMapper mapper, ExcelAppContext excelAppContext) : base(roleRepository, mapper)
        {
            this._roleRepository = roleRepository;
            this._mapper = mapper;
            this._excelAppContext = excelAppContext;
        }
    }
}