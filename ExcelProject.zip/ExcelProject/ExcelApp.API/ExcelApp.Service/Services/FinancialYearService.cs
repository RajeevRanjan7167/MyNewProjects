﻿using AutoMapper;
using ExcelApp.Infrastructure;
using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepInterfaces;
using ExcelApp.Service.IServices;

namespace ExcelApp.Service.Services
{
    public class FinancialYearService : BaseService<FinancialYearDM, IFinancialYearRepository, FinancialYear>, IFinancialYear
    {
        private readonly IFinancialYearRepository _financialYearRepository;
        private readonly IMapper _mapper;
        private readonly ExcelAppContext _excelAppContext;

        public FinancialYearService(IFinancialYearRepository financialYearRepository, IMapper mapper, ExcelAppContext excelAppContext) : base(financialYearRepository, mapper)
        {
            this._financialYearRepository = financialYearRepository;
            this._mapper = mapper;
            this._excelAppContext = excelAppContext;
        }
    }
}
