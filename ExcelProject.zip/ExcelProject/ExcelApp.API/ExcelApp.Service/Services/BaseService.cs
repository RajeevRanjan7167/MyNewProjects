﻿using AutoMapper;
using ExcelApp.CommonModule.Exceptions;
using ExcelApp.Repository.RepInterfaces;
using ExcelApp.Service.IServices;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ExcelApp.Service.Services
{
    public abstract class BaseService<TViewModel, TRepository, TDomainModel> : IBaseService<TViewModel>
        where TViewModel : class
        where TDomainModel : class
        where TRepository : IBaseRepository<TDomainModel>
    {
        private readonly TRepository _repository;
        private readonly IMapper _mapper;

        public BaseService(TRepository repository, IMapper mapper)
        {
            this._repository = repository;
            this._mapper = mapper;
        }

        public virtual async Task<TViewModel> Create(TViewModel entity)
        {
            var modelReturned = _mapper.Map<TDomainModel>(entity);
            return _mapper.Map<TViewModel>(await _repository.Create(modelReturned).ConfigureAwait(false));
        }

        public async Task<TViewModel> Delete(int id)
        {
            return _mapper.Map<TViewModel>(await _repository.Delete(id).ConfigureAwait(false));
        }

        public async Task<IEnumerable<TViewModel>> GetAll()
        {
            var modelReturned = await _repository.GetAll().ConfigureAwait(false);
            return _mapper.Map<IEnumerable<TViewModel>>(modelReturned);
        }

        public async virtual Task<TViewModel> Get(int id)
        {
            var objReturned = await _repository.Get(id).ConfigureAwait(false);
            if (objReturned == null)
                throw new DataNotFound(typeof(TViewModel).ToString());

            return _mapper.Map<TViewModel>(objReturned);
        }

        public virtual async Task<TViewModel> Update(TViewModel entity)
        {
            var modelReturned = _mapper.Map<TDomainModel>(entity);
            return _mapper.Map<TViewModel>(await _repository.Update(modelReturned).ConfigureAwait(false));
        }

        public async virtual Task<TViewModel> Update(int Id, TViewModel obj)
        {
            var existingData = await _repository.Get(Id).ConfigureAwait(false);
            var modelReturned = _mapper.Map(obj, existingData);
            return _mapper.Map<TViewModel>(await _repository.Update(modelReturned).ConfigureAwait(false));
        }
    }
}
