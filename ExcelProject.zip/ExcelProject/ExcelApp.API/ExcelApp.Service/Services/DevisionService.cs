﻿using AutoMapper;
using ExcelApp.Infrastructure;
using ExcelApp.Repository.Models;
using ExcelApp.Repository.RepInterfaces;
using ExcelApp.Service.IServices;

namespace ExcelApp.Service.Services
{
    public class DevisionService : BaseService<DevisionDM, IDevisionRepository, Devision>, IDevision
    {
        private readonly IDevisionRepository _devisionRepository;
        private readonly IMapper _mapper;
        private readonly ExcelAppContext _excelAppContext;

        public DevisionService(IDevisionRepository devisionRepository, IMapper mapper, ExcelAppContext excelAppContext) : base(devisionRepository, mapper)
        {
            this._devisionRepository = devisionRepository;
            this._mapper = mapper;
            this._excelAppContext = excelAppContext;
        }
    }
}