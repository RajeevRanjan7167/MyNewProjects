﻿using AutoMapper;
using ExcelApp.Infrastructure;
using ExcelApp.Repository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelApp.Service.Profiles
{
   public class MappingProfile:Profile
    {
        public MappingProfile()
        {
            CreateMap<FileUploadDM, FileUpload>().ReverseMap();
        }
    }
}
