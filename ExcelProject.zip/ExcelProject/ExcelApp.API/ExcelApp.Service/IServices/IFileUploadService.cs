﻿using ExcelApp.Infrastructure;

namespace ExcelApp.Service.IServices
{
    public interface IFileUploadService : IBaseService<FileUploadDM>
    {
    }
}

