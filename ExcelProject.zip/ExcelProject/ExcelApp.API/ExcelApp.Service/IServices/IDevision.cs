﻿using ExcelApp.Infrastructure;

namespace ExcelApp.Service.IServices
{
    public interface IDevision : IBaseService<DevisionDM>
    {       
    }
}
