﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelApp.Service.IServices
{
    public interface IBaseService<TViewModel> where TViewModel : class
    {
        Task<IEnumerable<TViewModel>> GetAll();
        Task<TViewModel> Get(int id);
        Task<TViewModel> Create(TViewModel entity);
        Task<TViewModel> Update(TViewModel entity);
        Task<TViewModel> Update(int Id,TViewModel obj);
        Task<TViewModel> Delete(int id);
        // int CountAsync(List<Criteria> criterias);
    }
}
