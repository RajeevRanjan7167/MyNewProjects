﻿using ExcelApp.Infrastructure;

namespace ExcelApp.Service.IServices
{
    public interface IFinancialYear : IBaseService<FinancialYearDM>
    {        
    }
}
