﻿using ExcelApp.Infrastructure;

namespace ExcelApp.Service.IServices
{
    public interface IDepartmet : IBaseService<DepartmetDM>
    {
    }
}
