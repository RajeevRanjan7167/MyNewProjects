﻿using ExcelApp.Infrastructure;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ExcelApp.Service.IServices
{
    public interface IAgging : IBaseService<AggingDM>
    {
        
    }
}
