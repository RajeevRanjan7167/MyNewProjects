﻿using ExcelApp.Infrastructure;
using ExcelApp.Service.IServices;
using Microsoft.AspNetCore.Hosting;

namespace ExcelApp.WebApi.Controllers
{
    public class FinancialYearController : GenericController<FinancialYearDM, IFinancialYear>
    {
        private readonly IFinancialYear _financialYear;
        private readonly IWebHostEnvironment _hostEnvironment;

        public FinancialYearController(IFinancialYear financialYear, IWebHostEnvironment hostEnvironment) : base(financialYear, hostEnvironment)
        {
            this._financialYear = financialYear;
            this._hostEnvironment = hostEnvironment;
        }
    }
}