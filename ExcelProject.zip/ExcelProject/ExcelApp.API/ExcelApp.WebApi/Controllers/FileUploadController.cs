﻿using ExcelApp.Infrastructure;
using ExcelApp.Service.IServices;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;

namespace ExcelApp.WebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class FileUploadController : GenericController<FileUploadDM, IFileUploadService>
    {
        private readonly IFileUploadService _fileUploadService;
        private readonly IWebHostEnvironment _hostEnvironment;

        public FileUploadController(IFileUploadService fileUploadService, IWebHostEnvironment hostEnvironment) : base(fileUploadService, hostEnvironment)
        {
            this._fileUploadService = fileUploadService;
            this._hostEnvironment = hostEnvironment;
        }
    }
}
