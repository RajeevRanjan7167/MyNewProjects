﻿using ExcelApp.Infrastructure;
using ExcelApp.Service.IServices;
using Microsoft.AspNetCore.Hosting;

namespace ExcelApp.WebApi.Controllers
{
    public class RoleController : GenericController<RolesDM, IRoles>
    {
        private readonly IRoles _roles;
        private readonly IWebHostEnvironment _hostEnvironment;

        public RoleController(IRoles roles, IWebHostEnvironment hostEnvironment) : base(roles, hostEnvironment)
        {
            this._roles = roles;
            this._hostEnvironment = hostEnvironment;
        }
    }
}