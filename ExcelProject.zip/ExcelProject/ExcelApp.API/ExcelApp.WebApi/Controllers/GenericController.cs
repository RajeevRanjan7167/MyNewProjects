﻿using ExcelApp.Service.IServices;
using ExcelApp.WebApi.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace ExcelApp.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public abstract class GenericController<TViewModel, TService> : ControllerBase
        where TService : IBaseService<TViewModel>
        where TViewModel : class
    {
        private readonly TService _service;
        private readonly IWebHostEnvironment _environment;


        public GenericController(TService service, IWebHostEnvironment environment)
        {
            this._service = service;
            this._environment = environment;
        }

        [HttpGet]
        public async virtual Task<commonModel.Response<TViewModel>> GetAll()
        {
            var list = await _service.GetAll().ConfigureAwait(false);
            return new commonModel.Response<TViewModel>()
            {
                list = list,
                status = true
            };
        }

        [HttpGet("{id}")]
        public async virtual Task<commonModel.Response<TViewModel>> Get(int id)
        {
            return new commonModel.Response<TViewModel>()
            {
                data = await _service.Get(id).ConfigureAwait(false),
                status = true
            };
        }

        [HttpPut("{id}")]
        public async virtual Task<commonModel.Response<TViewModel>> put(int id, TViewModel viewModel)
        {
            if (viewModel == null || id == 0)
                throw new ArgumentNullException("Data master is null");

            return new commonModel.Response<TViewModel>()
            {
                data = await _service.Update(id, viewModel).ConfigureAwait(false),
                status = true
            };
        }

        [HttpPost]
        public async virtual Task<commonModel.Response<TViewModel>> Post(TViewModel viewModel)
        {
            if (viewModel == null)
                throw new ArgumentNullException("Data master is null");

            return new commonModel.Response<TViewModel>()
            {
                data = await _service.Create(viewModel).ConfigureAwait(false),
                status = true
            };
        }

        [HttpDelete("{id}")]
        public async Task<commonModel.Response<TViewModel>> delete(int id)
        {
            return new commonModel.Response<TViewModel>()
            {
                data = await _service.Delete(id).ConfigureAwait(false),
                status = true
            };
        }
    }
}
