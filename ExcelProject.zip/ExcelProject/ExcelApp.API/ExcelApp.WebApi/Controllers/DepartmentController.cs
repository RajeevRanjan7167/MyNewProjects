﻿using ExcelApp.Infrastructure;
using ExcelApp.Service.IServices;
using Microsoft.AspNetCore.Hosting;

namespace ExcelApp.WebApi.Controllers
{
    public class DepartmentController : GenericController<DepartmetDM, IDepartmet>
    {
        private readonly IDepartmet _departmetService;
        private readonly IWebHostEnvironment _hostEnvironment;

        public DepartmentController(IDepartmet departmetService, IWebHostEnvironment hostEnvironment) : base(departmetService, hostEnvironment)
        {
            this._departmetService = departmetService;
            this._hostEnvironment = hostEnvironment;
        }


    }
}