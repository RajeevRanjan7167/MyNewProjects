﻿using ExcelApp.Infrastructure;
using ExcelApp.Service.IServices;
using Microsoft.AspNetCore.Hosting;

namespace ExcelApp.WebApi.Controllers
{
    public class DevisionController : GenericController<DevisionDM, IDevision>
    {
        private readonly IDevision _devisionService;
        private readonly IWebHostEnvironment _hostEnvironment;

        public DevisionController(IDevision devisionService, IWebHostEnvironment hostEnvironment) : base(devisionService, hostEnvironment)
        {
            this._devisionService = devisionService;
            this._hostEnvironment = hostEnvironment;
        }
    }
}