﻿using ExcelApp.Infrastructure;
using ExcelApp.Service.IServices;
using ExcelApp.WebApi.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ExcelApp.WebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AgingController : GenericController<AggingDM, IAgging>
    {
        private readonly IAgging _aggingService;
        private readonly IWebHostEnvironment _hostEnvironment;

        public AgingController(IAgging aggingService, IWebHostEnvironment hostEnvironment) : base(aggingService, hostEnvironment)
        {
            this._aggingService = aggingService;
            this._hostEnvironment = hostEnvironment;
        }


    }
}