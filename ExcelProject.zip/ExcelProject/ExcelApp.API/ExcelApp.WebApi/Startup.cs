//using ExcelApp.Repository.RepImplantation;
//using ExcelApp.Repository.RepInterfaces;
//using ExcelApp.Service.IServices;
//using ExcelApp.Service.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Okta.AspNetCore;
using System.Reflection;
using System.Text.Json.Serialization;
using ExcelApp.IOC;

namespace ExcelApp.WebApi
{
    public class Startup
    {
        readonly string ExcelOrigins = "_ExcelOrigins";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
             services.ConfigureIOC(); //  Register IOC

            // Cors
            services.AddCors(options =>
            {
                options.AddPolicy(name: ExcelOrigins, builder =>
                {
                    builder.WithOrigins("http://localhost:4200", "https://localhost:44315")
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                    .WithExposedHeaders("X-Pagination");
                });
            });

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultSignInScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddOktaWebApi(new OktaWebApiOptions()
            {

                OktaDomain = Configuration["Okta:OktaDomain"],
            });

            services.AddAuthorization();

            services.AddControllers().AddJsonOptions(options =>
            {
                var enumConverter = new JsonStringEnumConverter();
                options.JsonSerializerOptions.Converters.Add(enumConverter);
            })
            .AddNewtonsoftJson();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "ExcelApp.WebApi", Version = "v1" });
            });

            services.AddDependencyInjections(Configuration);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "ExcelApp.WebApi v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseCors(ExcelOrigins);

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }

    internal static partial class CustomExtensionMethods
    {
        public static IServiceCollection AddDependencyInjections(this IServiceCollection services, IConfiguration configuration)
        {
            //services.AddScoped<IAgingRepository, AgingRepository>();
            //services.AddScoped<IAgging, AggingService>();
            //services.AddScoped<IDepartmentRepository, DepartmentRepository>();
            //services.AddScoped<IDepartmet, DepartmetServices>();
            //services.AddScoped<IDevisionRepository, DevisionRepository>();
            //services.AddScoped<IDevision, DevisionService>();
            //services.AddScoped<IFinancialYearRepository, FinancialYearRepository>();
            //services.AddScoped<IFinancialYear, FinancialYearService>();
            //services.AddScoped<IRoleRepository, RoleRepository>();
            //services.AddScoped<IRoles, RolesService>();
            //services.AddScoped<IFileUploadRepository, FileUploadRepository>();
            //services.AddScoped<IFileUploadService, FileUploadService>();

            services.AddAutoMapper(Assembly.GetExecutingAssembly());
            return services;
        }
    }
}
