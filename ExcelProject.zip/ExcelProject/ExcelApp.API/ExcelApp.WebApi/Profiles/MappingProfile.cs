﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using ExcelApp.Infrastructure;
using ExcelApp.Repository.Models;

namespace ExcelApp.WebApi.Profiles
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<AggingDM, Agging>().ReverseMap();
            CreateMap<DepartmetDM, Departmet>().ReverseMap();
            CreateMap<DevisionDM, Devision>().ReverseMap();
            CreateMap<FileUploadDM, FileUpload>().ReverseMap();
            CreateMap<FinancialYearDM, FinancialYear>().ReverseMap();
            CreateMap<RolesDM, Role>().ReverseMap();
        }
    }
}
