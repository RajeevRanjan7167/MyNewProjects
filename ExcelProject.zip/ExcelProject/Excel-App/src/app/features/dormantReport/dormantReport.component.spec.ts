/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { DormantReportComponent } from './dormantReport.component';

describe('DormantReportComponent', () => {
  let component: DormantReportComponent;
  let fixture: ComponentFixture<DormantReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DormantReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DormantReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
