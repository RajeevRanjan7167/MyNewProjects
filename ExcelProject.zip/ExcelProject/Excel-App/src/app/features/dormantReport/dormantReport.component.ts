import { Component, OnInit } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'app-dormantReport',
  templateUrl: './dormantReport.component.html',
  styleUrls: ['./dormantReport.component.css']
})
export class DormantReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
