import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DormantReportComponent } from 'src/app/features/dormantReport/dormantReport.component';

const routers: Routes = [
    {
        path: '',
        component: DormantReportComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routers)],
    exports: [RouterModule]
})
export class DormantReportRoutingModule { }
