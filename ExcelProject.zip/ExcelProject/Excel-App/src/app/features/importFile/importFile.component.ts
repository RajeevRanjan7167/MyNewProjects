import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Routes } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpClientModule, HttpEventType } from '@angular/common/http';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { ApplicationSetting } from 'src/app/app.settings';
import { Toaster } from 'src/app/shared/helpers/toaster';
import { LoaderService } from 'src/app/shared/helpers/loadderService';
import { httpGenericService } from 'src/app/shared/helpers/httpGenericService';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'app-importFile',
  templateUrl: './importFile.component.html',
  styleUrls: ['./importFile.component.scss']
})
export class ImportFileComponent implements OnInit {

  importForm: FormGroup;
  fileIndex: number;
  uploadedFiles: any[] = [];

  constructor(
    private messageService: MessageService,
    private httpService: HttpClient,
    private appSetting: ApplicationSetting,
    private loader: LoaderService,
    private toaster: Toaster,
    public confirmationService: ConfirmationService,
    private optionalRoute: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder,
    private service: httpGenericService
  ) {

  }

  ngOnInit() {

  }

  onBasicUpload(event) {

    // for (let file of event.files) {
    //   this.uploadedFiles.push(file);
    // }

    // this.messageService.add({ severity: 'info', summary: 'File Uploaded', detail: '' });
  }

  uploadFile() {
    if (this.uploadedFiles && this.uploadedFiles.length > 0) {
      let FormData: FormData = new FormData();

      for (var i = 0; i < this.uploadedFiles.length; i++) {
        let fileUpload = <File>this.uploadedFiles[i];
        FormData.append('file', fileUpload);
      }

      this.httpService.post(this.appSetting.FILEUPLOAD_CREATE, FormData, { reportProgress: true, observe: 'events' })
        .subscribe(objEvent => {
          if (objEvent.type === HttpEventType.UploadProgress) {

          }
        });
    }
  }


  onSelectFiles(event) {
    debugger;
    if (event.files && event.files.length > 0) {
      for (var fileIndex = 0; fileIndex < event.files.length; fileIndex++) {

        this.uploadedFiles.push(event.files[fileIndex]);
      }
      console.log(this.uploadedFiles);
    }

    const frmData = new FormData();
    let file
    frmData.append('file', this.uploadedFiles[0]);
  }

  onRemoveFiles(event) {
    debugger;
    if (event.files && event.files.length > 0) {
      this.fileIndex = 0;
      for (this.fileIndex = 0; this.fileIndex < this.uploadedFiles.length; this.fileIndex++) {
        // this.uploadedFiles.pop(event.files[this.fileIndex]);
      }
      console.log(this.uploadedFiles);
    }
  }
}
