import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ImportFileComponent } from 'src/app/features/importFile/importFile.component';

const routers: Routes = [
    {
        path: '',
        component: ImportFileComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routers)],
    exports: [RouterModule]
})
export class ImportFileRoutingModule { }
