import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/shared/layout/header-breadcrumb/header-breadcrumb.module';
import { ImportFileComponent } from 'src/app/features/importFile/importFile.component';
import { ImportFileRoutingModule } from 'src/app/features/importFile/importFile.routing';

@NgModule({
    imports: [
        CommonModule,
        ImportFileRoutingModule,
        AppCommonModule,
        HeaderBreadCrumbModule
    ],
    declarations: [
        ImportFileComponent
    ]
})
export class ImportFileModule { }
