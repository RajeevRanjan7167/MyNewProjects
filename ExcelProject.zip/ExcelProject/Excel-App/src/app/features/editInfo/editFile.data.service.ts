import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root',
})

export class EditInfoDataService {
    constructor(private http: HttpClient) { }

    getEditInfo() {
        return this.http.get<any>('assets/testing.json')
            .toPromise()
            .then(res => <Book[]>res.data)
            .then(data => {
                return data;
            });
    }
}

export interface Book {
    name;
    price;
    author;
}
