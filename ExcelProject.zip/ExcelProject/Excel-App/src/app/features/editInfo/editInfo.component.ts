import { Component, OnInit } from '@angular/core';
import { Book, EditInfoDataService } from 'src/app/features/editInfo/editFile.data.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'app-editInfo',
  templateUrl: './editInfo.component.html',
  styleUrls: ['./editInfo.component.css']
})
export class EditInfoComponent implements OnInit {

  books: Book[];
  pageSize: any = 10;
  rowPerPageOptions: number[] = [10, 20, 40, 50, 100];

  constructor(private bookService: EditInfoDataService) { }

  ngOnInit() {
    this.bookService.getEditInfo().
      then(books => this.books = books);
  }

  onRowEditInit(book: Book) {
    console.log('Row edit initialized');
  }

  onRowEditSave(book: Book) {
    console.log('Row edit saved');
  }

  onRowEditCancel(book: Book, index: number) {
    console.log('Row edit cancelled');
  }
}
