import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/shared/layout/header-breadcrumb/header-breadcrumb.module';
import { EditInfoComponent } from 'src/app/features/editInfo/editInfo.component';
import { EditInfoRoutingModule } from 'src/app/features/editInfo/editInfo.routing';

@NgModule({
    imports: [
        CommonModule,
        EditInfoRoutingModule,
        AppCommonModule,
        HeaderBreadCrumbModule
    ],
    declarations: [
        EditInfoComponent
    ]
})
export class EditInfoModule { }
