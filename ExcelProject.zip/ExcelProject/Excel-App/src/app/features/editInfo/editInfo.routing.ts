import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditInfoComponent } from 'src/app/features/editInfo/editInfo.component';

const routers: Routes = [
    {
        path: '',
        component: EditInfoComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routers)],
    exports: [RouterModule]
})
export class EditInfoRoutingModule { }
