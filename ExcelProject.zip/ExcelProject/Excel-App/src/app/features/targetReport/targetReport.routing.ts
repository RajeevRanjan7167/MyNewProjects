import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TargetReportComponent } from 'src/app/features/targetReport/targetReport.component';

const routers: Routes = [
    {
        path: '',
        component: TargetReportComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routers)],
    exports: [RouterModule]
})
export class TargetReportRoutingModule { }
