import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-targetReport',
  templateUrl: './targetReport.component.html',
  styleUrls: ['./targetReport.component.css']
})
export class TargetReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
