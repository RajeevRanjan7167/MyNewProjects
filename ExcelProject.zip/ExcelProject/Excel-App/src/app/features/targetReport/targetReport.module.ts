import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/shared/layout/header-breadcrumb/header-breadcrumb.module';
import { TargetReportComponent } from 'src/app/features/targetReport/targetReport.component';
import { TargetReportRoutingModule } from 'src/app/features/targetReport/targetReport.routing';

@NgModule({
    imports: [
        CommonModule,
        TargetReportRoutingModule,
        AppCommonModule,
        HeaderBreadCrumbModule
    ],
    declarations: [
        TargetReportComponent
    ]
})
export class TargetReportModule { }
