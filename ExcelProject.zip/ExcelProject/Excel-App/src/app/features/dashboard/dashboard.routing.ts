import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from 'src/app/features/dashboard/dashboard.component';
import { OktaAuthGuard } from '@okta/okta-angular';

const routes: Routes = [
    {
        path: '',
        component: DashboardComponent,
        canActivate: [OktaAuthGuard],
        data: {
            title: 'Dashboard'
        }
    },
    {
        path: '/dashboard',
        component: DashboardComponent,
        canActivate: [OktaAuthGuard],
        data: {
            title: 'Dashboard'
        }
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class DashboardRoutingModule { }
