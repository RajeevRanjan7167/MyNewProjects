import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CombinedReportComponent } from 'src/app/features/combinedReport/combinedReport.component';

const routers: Routes = [
    {
        path: '',
        component: CombinedReportComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routers)],
    exports: [RouterModule]
})
export class CombinedReportRoutingModule { }
