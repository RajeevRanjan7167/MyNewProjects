import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppCommonModule } from 'src/app/app.common.module';
import { HeaderBreadCrumbModule } from 'src/app/shared/layout/header-breadcrumb/header-breadcrumb.module';
import { CombinedReportComponent } from 'src/app/features/combinedReport/combinedReport.component';
import { CombinedReportRoutingModule } from 'src/app/features/combinedReport/combinedReport.routing';

@NgModule({
    imports: [
        CommonModule,
        CombinedReportRoutingModule,
        AppCommonModule,
        HeaderBreadCrumbModule
    ],
    declarations: [
        CombinedReportComponent
    ]
})
export class CombinedReportModule { }
