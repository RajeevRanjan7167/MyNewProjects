import { Component, OnInit } from '@angular/core';
import { CombinedReportDataService } from 'src/app/features/combinedReport/combinedReport.data.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'app-combinedReport',
  templateUrl: './combinedReport.component.html',
  styleUrls: ['./combinedReport.component.css']
})
export class CombinedReportComponent implements OnInit {

  constructor(
    private combinedReportDataService: CombinedReportDataService
  ) { }

  ngOnInit() {
    debugger;
    this.combinedReportDataService.getCombinedReport().then(data => {
      var aaa = data.data;
      console.log(aaa);
    });

  }

}
