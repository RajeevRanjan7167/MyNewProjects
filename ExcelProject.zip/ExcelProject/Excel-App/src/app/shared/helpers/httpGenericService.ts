import * as CryptoJS from 'chart.js';
import 'rxjs/add/operator/map';
import {
    HttpClient, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest,
    HttpHeaders, HttpResponse, HttpErrorResponse
} from '@angular/common/http';
import { Injectable, Injector } from '@angular/core';
import { Observable } from 'rxjs/observable';
import { Router } from '@angular/router';
import 'rxjs/add/operator/do';
import { OktaAuthService } from '@okta/okta-angular';
import { Toaster } from 'src/app/shared/helpers/toaster';

@Injectable()
export class httpGenericService {

    constructor(private http: HttpClient) {

    }

    public get<T>(url: string, headers?: HttpHeaders): Observable<T> {
        return this.http.get<T>(url, { headers: headers });
    }

    public post<T>(url, addInfo: any, headers?: HttpHeaders): Observable<T> {
        return this.http.post<T>(url, JSON.stringify(addInfo), { headers: headers });
    }

    public put<T>(url, itemToUpdate: any, headers?: HttpHeaders): Observable<T> {
        return this.http.put<T>(url, JSON.stringify(itemToUpdate), { headers: headers });
    }

    public patch<T>(url, itemToUpdate: any, headers?: HttpHeaders): Observable<T> {
        return this.http.patch<T>(url, JSON.stringify(itemToUpdate), { headers: headers });
    }

    public delete<T>(url: string, headers?: HttpHeaders): Observable<T> {
        return this.http.delete<T>(url, { headers: headers });
    }

    public download<T>(url: string): Observable<Blob> {
        return this.http.get(url, { responseType: 'blob' });
    }

    public downloadPost<T>(url: string, datatoPost: any): Observable<Blob> {
        return this.http.post(url, datatoPost, { responseType: 'blob' });
    }

    public upload<T>(url, uploadInfo: any): Observable<T> {
        return this.http.post<T>(url, uploadInfo);
    }
}

@Injectable()
export class CustomInterceptor implements HttpInterceptor {
    constructor(
        private injector: Injector,
        private oktaAuth: OktaAuthService
    ) { }


}
