import { Injectable } from '@angular/core';
import { MessageService } from 'primeng/api';

@Injectable()
export class Toaster {
    constructor(
        private messageService: MessageService,
    ) { }

    success(message: string, title: string, string = 'Success!') {
        this.messageService.add({ severity: 'success', summary: title, detail: message });
    }

    info(message: string, title: string, string = 'Info!') {
        this.messageService.add({ severity: 'info', summary: title, detail: message });
    }

    warning(message: string, title: string, string = 'Warning!') {
        this.messageService.add({ severity: 'warning', summary: title, detail: message });
    }

    error(message: string, title: string, string = 'Error!') {
        this.messageService.add({ severity: 'error', summary: title, detail: message });
    }
}
