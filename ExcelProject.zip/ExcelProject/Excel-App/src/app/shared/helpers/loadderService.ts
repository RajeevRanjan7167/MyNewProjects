import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class LoaderService {
    public status: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
    private timeout: any;

    show() {
        this.status.next(true);

        this.timeout = setTimeout(() => {
            this.hide();
        }, 90000);
    }

    hide() {
        this.status.next(false);
        clearTimeout(this.timeout);
    }
}
