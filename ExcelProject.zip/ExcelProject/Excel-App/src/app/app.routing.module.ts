import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuard } from 'src/app/core/gaurds/auth.gaurd';
import { LayoutComponent } from 'src/app/shared/layout/layout.component';
import { ErrorComponent } from './shared/error/error.component';
import { OktaAuthGuard, OktaCallbackComponent } from '@okta/okta-angular';

const appRoutes: Routes = [
    {
        path: 'login/callback',
        component: OktaCallbackComponent
    },
    {
        path: 'login',
        loadChildren: () => import('src/app/features/login/login.module').then(m => m.LoginModule),
        data: { title: 'Login Page', url: 'login' }
    },
    {
        path: 'register',
        loadChildren: () => import('src/app/features/register-user/register-user.module').then(m => m.RegisterUserModule)
    },
    {
        path: '',
        component: LayoutComponent,
        canActivateChild: [OktaAuthGuard],
        data: {
            title: 'Home',
            url: '/dashboard'
        },
        children: [{
            path: 'dashboard',
            loadChildren: () => import('src/app/features/dashboard/dashboard.module').then(m => m.DashboardModule),
            canActivate: [OktaAuthGuard]
        },
        {
            path: 'import',
            loadChildren: () => import('src/app/features/importFile/importFile.module').then(m => m.ImportFileModule),
            canActivate: [OktaAuthGuard]
        },
        {
            path: 'editInfo',
            loadChildren: () => import('src/app/features/editInfo/editInfo.module').then(m => m.EditInfoModule),
            canActivate: [OktaAuthGuard]
        },
        {
            path: 'combinedreport',
            loadChildren: () => import('src/app/features/combinedReport/combinedReport.module').then(m => m.CombinedReportModule),
            canActivate: [OktaAuthGuard]
        },
        {
            path: 'targetreport',
            loadChildren: () => import('src/app/features/targetReport/targetReport.module').then(m => m.TargetReportModule),
            canActivate: [OktaAuthGuard]
        },
        {
            path: 'dormantreport',
            loadChildren: () => import('src/app/features/dormantReport/dormantReport.module').then(m => m.DormantReportModule),
            canActivate: [OktaAuthGuard]
        },
        {
            path: 'departments',
            loadChildren: () => import('src/app/features/department/department.module').then(m => m.DepartmentModule),
            canActivate: [OktaAuthGuard]
        },
        {
            path: 'employees',
            loadChildren: () => import('src/app/features/employees/employees.module').then(m => m.EmployeesModule),
            canActivate: [OktaAuthGuard]
        },
        {
            path: 'aboutus',
            loadChildren: () => import('src/app/features/aboutus/aboutus.module').then(m => m.AboutUsModule),
            canActivate: [OktaAuthGuard]
        },
        {
            path: 'contactus',
            loadChildren: () => import('src/app/features/contactus/contactus.module').then(m => m.ContactUsModule),
            canActivate: [OktaAuthGuard]
        }]
    },
    {
        path: 'error',
        component: ErrorComponent,
        //loadChildren: () => import('src/app/shared/error/error.module').then(m => m.ErrorModule)
    },
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    }
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes, { relativeLinkResolution: 'legacy' })],
    exports: [RouterModule]
})
export class AppRoutingModule { }