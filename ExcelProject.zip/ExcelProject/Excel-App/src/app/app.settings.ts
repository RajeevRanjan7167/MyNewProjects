import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable()
export class ApplicationSetting {

    public baseURL: string;
    public environment = 'Dev';
    public version: string;

    //#region Messages
    public readonly SAVE_MESSAGE: string = 'Saved successfully!';
    public readonly ERROR_MESSAGE: string = 'An error occured!';
    public readonly DELETION_MESSAGE: string = 'Deleted successfully!';
    public readonly UPDATION_MESSAGE: string = 'Updated successfully!';

    public readonly INVALID_CRED_MESSAGE: string = 'Invlid Credentials Entered!';
    public readonly FILE_UPLOAD_MESSAGE: string = 'File uploaded successfully! Please check the addressed location';
    public readonly FILE_DOWNLOAD_MESSAGE: string = 'File download successfully!';
    //#endregion

    //#region settings
    public readonly USER_SETTING: String = 'User';
    public readonly TOKEN_SETTING: String = 'Token';
    public readonly MAPS_SEETING: String = 'Map';
    public readonly DASHBOARD: String;
    //#endregion

    //#region  API URL'S Declarations

    public readonly AGGING_URL: String;
    public readonly AGGING_URLBYID: String;
    public readonly AGGING_CREATE: String;
    public readonly AGGING_UPDATE: String;
    public readonly AGGING_DELETE: String;

    public readonly DEPARTMET_URL: String;
    public readonly DEPARTMET_URLBYID: String;
    public readonly DEPARTMET_CREATE: String;
    public readonly DEPARTMET_UPDATE: String;
    public readonly DEPARTMET_DELETE: String;

    public readonly DEVISION_URL: String;
    public readonly DEVISION_URLBYID: String;
    public readonly DEVISION_CREATE: String;
    public readonly DEVISION_UPDATE: String;
    public readonly DEVISION_DELETE: String;

    public readonly FILEUPLOAD_URL: String;
    public readonly FILEUPLOAD_URLBYID: String;
    public readonly FILEUPLOAD_CREATE: String;
    public readonly FILEUPLOAD_UPDATE: String;
    public readonly FILEUPLOAD_DELETE: String;

    public readonly FINANCIALYEAR_URL: String;
    public readonly FINANCIALYEAR_URLBYID: String;
    public readonly FINANCIALYEAR_CREATE: String;
    public readonly FINANCIALYEAR_UPDATE: String;
    public readonly FINANCIALYEAR_DELETE: String;

    public readonly ROLE_URL: String;
    public readonly ROLE_URLBYID: String;
    public readonly ROLE_CREATE: String;
    public readonly ROLE_UPDATE: String;
    public readonly ROLE_DELETE: String;

    //#endregion

    //#region Constructor
    constructor() {
        this.baseURL = environment.apiUrl;
        this.environment = environment.environment;
        this.version = environment.version;


        this.AGGING_URL = this.baseURL + 'api/Aging';
        this.AGGING_URLBYID = this.baseURL + 'api/Aging/';
        this.AGGING_CREATE = this.baseURL + 'api/Aging';
        this.AGGING_UPDATE = this.baseURL + 'api/Aging/';
        this.AGGING_DELETE = this.baseURL + 'api/Aging/';

        this.DEPARTMET_URL = this.baseURL + 'api/Department';
        this.DEPARTMET_URLBYID = this.baseURL + 'api/Department/';
        this.DEPARTMET_CREATE = this.baseURL + 'api/Department';
        this.DEPARTMET_UPDATE = this.baseURL + 'api/Department/';
        this.DEPARTMET_DELETE = this.baseURL + 'api/Department/';

        this.DEVISION_URL = this.baseURL + 'api/Devision';
        this.DEVISION_URLBYID = this.baseURL + 'api/Devision/';
        this.DEVISION_CREATE = this.baseURL + 'api/Devision';
        this.DEVISION_UPDATE = this.baseURL + 'api/Devision/';
        this.DEVISION_DELETE = this.baseURL + 'api/Devision/';

        this.FILEUPLOAD_URL = this.baseURL + 'api/FileUpload';
        this.FILEUPLOAD_URLBYID = this.baseURL + 'api/FileUpload/';
        this.FILEUPLOAD_CREATE = this.baseURL + 'api/FileUpload';
        this.FILEUPLOAD_UPDATE = this.baseURL + 'api/FileUpload/';
        this.FILEUPLOAD_DELETE = this.baseURL + 'api/FileUpload/';

        this.FINANCIALYEAR_URL = this.baseURL + 'api/FinancialYear';
        this.FINANCIALYEAR_URLBYID = this.baseURL + 'api/FinancialYear/';
        this.FINANCIALYEAR_CREATE = this.baseURL + 'api/FinancialYear';
        this.FINANCIALYEAR_UPDATE = this.baseURL + 'api/FinancialYear/';
        this.FINANCIALYEAR_DELETE = this.baseURL + 'api/FinancialYear/';

        this.ROLE_URL = this.baseURL + 'api/Role';
        this.ROLE_URLBYID = this.baseURL + 'api/Role/';
        this.ROLE_CREATE = this.baseURL + 'api/Role';
        this.ROLE_UPDATE = this.baseURL + 'api/Role/';
        this.ROLE_DELETE = this.baseURL + 'api/Role/';
    }
    //#endregion

}
