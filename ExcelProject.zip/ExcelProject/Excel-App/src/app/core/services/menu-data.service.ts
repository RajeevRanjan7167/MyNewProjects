import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CustomMenuItem } from '../models/menu-item.model';

@Injectable({
    providedIn: 'root',
})
/**
 * menu data service
 */
export class MenuDataService {

    public toggleMenuBar: BehaviorSubject<any> = new BehaviorSubject<any>(null);

    getMenuList(): CustomMenuItem[] {
        return [
            {
                Label: 'Home', Icon: 'fa-home', RouterLink: '/dashboard', Childs: null, IsChildVisible: false
            },
            {
                Label: 'Import', Icon: 'fa-file-import', RouterLink: '/import', Childs: null, IsChildVisible: false
            },
            {
                Label: 'Edit Info', Icon: 'fa-edit', RouterLink: '/editInfo', Childs: null, IsChildVisible: false
            },
            {
                Label: 'Report', Icon: 'fa-folder-open', RouterLink: null, Childs: [
                    { Label: 'Combined Master DTR Report', RouterLink: '/combinedreport', Childs: null, IsChildVisible: false },
                    { Label: 'Target Trends Report', RouterLink: '/targetreport', Childs: null, IsChildVisible: false },
                    { Label: 'Dormant Aging Report', RouterLink: '/dormantreport', Childs: null, IsChildVisible: false },
                ], IsChildVisible: false
            },
            {
                Label: 'Employees', Icon: 'fa-users', RouterLink: '/employees', Childs: null, IsChildVisible: false
            },
            {
                Label: 'Departments', Icon: 'fa-sitemap', RouterLink: '/departments', Childs: null, IsChildVisible: false
            },
            {
                Label: 'AboutUs', Icon: 'fa-info-circle', RouterLink: '/aboutus', Childs: null, IsChildVisible: false
            },
            {
                Label: 'ContactUs', Icon: 'fa-envelope', RouterLink: '/contactus', Childs: null, IsChildVisible: false
            },
            {
                Label: 'Error 404', Icon: 'fa-exclamation-triangle', RouterLink: '/error', Childs: null, IsChildVisible: false
            },
            {
                Label: 'Menu Level 1', Icon: 'fa-cart-plus', RouterLink: null, Childs: [
                    { Label: 'Menu Level 1.1', RouterLink: null, Childs: null, IsChildVisible: false },
                    {
                        Label: 'Menu Level 1.2', RouterLink: null, IsChildVisible: false, Childs: [
                            { Label: 'Menu Level 1.2.1', RouterLink: null, Childs: null, IsChildVisible: false },
                            { Label: 'Menu Level 1.2.2', RouterLink: null, Childs: null, IsChildVisible: false }
                        ]
                    }
                ], IsChildVisible: false
            }
        ];
    }
}
